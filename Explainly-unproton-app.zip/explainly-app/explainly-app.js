/* ============================================================
   EXPLAINLY APP — interactions, router, renderers, tweaks
   ============================================================ */
(function () {
  'use strict';
  const $  = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const root = document.documentElement;
  const reduce = matchMedia('(prefers-reduced-motion:reduce)').matches;
  const D = window.EX;

  const MODE_LABELS = { eli5: 'ELI5', normal: 'Normal', deep: 'Deep', why: 'Why?' };
  const ICONS = {
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    star: '<polygon points="12 2 15 9 22 9.3 16.5 14 18.5 21 12 17 5.5 21 7.5 14 2 9.3 9 9 12 2"/>',
    book: '<path d="M4 5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v16l-8-4-8 4V5Z"/>',
    brief:'<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
    atom: '<circle cx="12" cy="12" r="2"/><path d="M12 4c5 0 9 3.6 9 8s-4 8-9 8-9-3.6-9-8 4-8 9-8Z" transform="rotate(60 12 12)"/><path d="M12 4c5 0 9 3.6 9 8s-4 8-9 8-9-3.6-9-8 4-8 9-8Z" transform="rotate(-60 12 12)"/>',
  };
  const CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="20 6 9 17 4 12"/></svg>';
  const esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  /* ============================================================
     STATE
     ============================================================ */
  const state = {
    authed: false,
    collection: 'all',
    mode: 'all',
    sort: 'recent',
    view: 'list',
    search: '',
    period: 'monthly',
    open: {},          // expanded card ids
    saves: D.SAVES.map(s => ({ ...s })),
  };

  /* ============================================================
     TWEAKS — root attributes + host protocol + persistence
     ============================================================ */
  const TWEAK_KEYS = ['theme', 'accent', 'font', 'card', 'radius'];
  const TWEAK_STORE = 'explainly-app-tweaks';
  const tweaks = loadTweaks();

  function loadTweaks() {
    const def = { theme: 'dark', accent: 'indigo', font: 'techy', card: 'elevated', radius: 'rounded' };
    let saved = {};
    try { saved = JSON.parse(localStorage.getItem(TWEAK_STORE) || '{}'); } catch (e) {}
    return { ...def, ...saved };
  }
  function applyTweaks() {
    root.setAttribute('data-theme', tweaks.theme);
    root.setAttribute('data-accent', tweaks.accent);
    root.setAttribute('data-font', tweaks.font);
    root.setAttribute('data-card', tweaks.card);
    root.setAttribute('data-radius', tweaks.radius);
    swapLogos(tweaks.accent);
  }
  function setTweak(key, val) {
    tweaks[key] = val;
    try { localStorage.setItem(TWEAK_STORE, JSON.stringify(tweaks)); } catch (e) {}
    try { window.parent.postMessage({ type: '__edit_mode_set_keys', edits: { [key]: val } }, '*'); } catch (e) {}
    applyTweaks();
    syncTweakUI();
  }
  function swapLogos(accent) {
    $$('.brand-logo').forEach(img => { img.src = 'assets/logo-' + accent + '.png'; });
  }

  // theme toggle buttons (kept in sync with tweaks)
  function toggleTheme() { setTweak('theme', tweaks.theme === 'light' ? 'dark' : 'light'); }
  $('#theme-side')?.addEventListener('click', toggleTheme);
  $('#theme-top')?.addEventListener('click', toggleTheme);

  applyTweaks();

  // ---- Tweaks panel UI ----
  const panelStyle = `
  #tw-panel{position:fixed;right:18px;bottom:18px;z-index:90;width:300px;max-width:calc(100vw - 36px);
    border-radius:18px;background:var(--glass);border:1px solid var(--line-2);
    backdrop-filter:blur(18px) saturate(150%);-webkit-backdrop-filter:blur(18px) saturate(150%);
    box-shadow:var(--shadow);font-family:var(--body);color:var(--ink);display:none;overflow:hidden}
  #tw-panel.show{display:block}
  .tw-head{display:flex;align-items:center;gap:9px;padding:14px 16px;border-bottom:1px solid var(--line);cursor:grab}
  .tw-head b{font-family:var(--display);font-size:14px;font-weight:600}
  .tw-head .tw-dot{width:8px;height:8px;border-radius:50%;background:linear-gradient(var(--a1),var(--a2))}
  .tw-head .tw-x{margin-left:auto;display:grid;place-items:center;width:26px;height:26px;border-radius:8px;color:var(--ink-3)}
  .tw-head .tw-x:hover{background:var(--surface-2);color:var(--ink)}
  .tw-head .tw-x svg{width:15px;height:15px}
  .tw-body{padding:6px 16px 16px;max-height:min(70vh,520px);overflow-y:auto}
  .tw-sec{font-family:var(--mono);font-size:10px;letter-spacing:.16em;text-transform:uppercase;color:var(--ink-3);
    margin:16px 0 9px}
  .tw-seg{display:flex;gap:5px;flex-wrap:wrap}
  .tw-seg button{flex:1;min-width:fit-content;padding:8px 10px;border-radius:10px;border:1px solid var(--line);
    background:var(--surface);color:var(--ink-2);font-size:12.5px;font-weight:600;transition:.18s;white-space:nowrap}
  .tw-seg button:hover{border-color:var(--line-2);color:var(--ink)}
  .tw-seg button.on{color:#fff;background:linear-gradient(120deg,var(--a1),var(--a2));border-color:transparent}
  .tw-swatches{display:flex;gap:9px;flex-wrap:wrap}
  .tw-sw{width:38px;height:38px;border-radius:11px;border:2px solid transparent;cursor:pointer;position:relative;transition:.18s}
  .tw-sw:hover{transform:translateY(-2px)}
  .tw-sw.on{border-color:var(--ink)}
  .tw-sw.on::after{content:"";position:absolute;inset:0;border-radius:9px;box-shadow:0 0 0 2px var(--bg) inset}`;
  const st = document.createElement('style'); st.textContent = panelStyle; document.head.appendChild(st);

  const ACCENT_SW = {
    indigo: '#6366f1', navy: '#3b82f6', slate: '#5b9bd5', abyss: '#22d3ee', forest: '#22c55e',
  };

  function buildPanel() {
    const seg = (label, key, opts) => `<div class="tw-sec">${label}</div><div class="tw-seg" data-key="${key}">` +
      opts.map(o => `<button data-v="${o.v}">${o.l}</button>`).join('') + '</div>';
    const html = `
    <div id="tw-panel">
      <div class="tw-head" id="tw-head"><span class="tw-dot"></span><b>Tweaks</b>
        <button class="tw-x" id="tw-x" aria-label="Close"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M18 6 6 18M6 6l12 12"/></svg></button>
      </div>
      <div class="tw-body">
        ${seg('Theme', 'theme', [{ v: 'dark', l: 'Dark' }, { v: 'light', l: 'Light' }])}
        <div class="tw-sec">Accent</div>
        <div class="tw-swatches" data-key="accent">
          ${Object.keys(ACCENT_SW).map(a => `<button class="tw-sw" data-v="${a}" style="background:${ACCENT_SW[a]}" aria-label="${a}"></button>`).join('')}
        </div>
        ${seg('Display font', 'font', [{ v: 'techy', l: 'Techy' }, { v: 'humanist', l: 'Humanist' }, { v: 'rounded', l: 'Rounded' }])}
        ${seg('Card style', 'card', [{ v: 'elevated', l: 'Elevated' }, { v: 'outline', l: 'Outline' }, { v: 'glass', l: 'Glass' }])}
        ${seg('Corner radius', 'radius', [{ v: 'sharp', l: 'Sharp' }, { v: 'rounded', l: 'Rounded' }, { v: 'soft', l: 'Soft' }])}
      </div>
    </div>`;
    $('#tweaks-root').innerHTML = html;

    $$('#tw-panel .tw-seg').forEach(g => {
      g.addEventListener('click', e => {
        const b = e.target.closest('button'); if (!b) return;
        setTweak(g.dataset.key, b.dataset.v);
      });
    });
    $('#tw-panel .tw-swatches').addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      setTweak('accent', b.dataset.v);
    });
    $('#tw-x').addEventListener('click', dismissPanel);
    makeDraggable($('#tw-panel'), $('#tw-head'));
    syncTweakUI();
  }
  function syncTweakUI() {
    $$('#tw-panel .tw-seg').forEach(g => {
      const k = g.dataset.key;
      $$('button', g).forEach(b => b.classList.toggle('on', b.dataset.v === tweaks[k]));
    });
    $$('#tw-panel .tw-sw').forEach(b => b.classList.toggle('on', b.dataset.v === tweaks.accent));
  }
  function openPanel()  { $('#tw-panel')?.classList.add('show'); }
  function dismissPanel(){ $('#tw-panel')?.classList.remove('show'); try { window.parent.postMessage({ type: '__edit_mode_dismissed' }, '*'); } catch (e) {} }

  function makeDraggable(panel, handle) {
    let sx, sy, ox, oy, drag = false;
    handle.addEventListener('pointerdown', e => {
      if (e.target.closest('.tw-x')) return;
      drag = true; handle.setPointerCapture(e.pointerId);
      const r = panel.getBoundingClientRect();
      sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top;
      panel.style.transition = 'none';
    });
    handle.addEventListener('pointermove', e => {
      if (!drag) return;
      const nx = Math.max(8, Math.min(innerWidth - panel.offsetWidth - 8, ox + e.clientX - sx));
      const ny = Math.max(8, Math.min(innerHeight - 60, oy + e.clientY - sy));
      panel.style.left = nx + 'px'; panel.style.top = ny + 'px';
      panel.style.right = 'auto'; panel.style.bottom = 'auto';
    });
    handle.addEventListener('pointerup', () => { drag = false; });
  }

  buildPanel();
  // host protocol
  window.addEventListener('message', e => {
    const t = e?.data?.type;
    if (t === '__activate_edit_mode') openPanel();
    else if (t === '__deactivate_edit_mode') $('#tw-panel')?.classList.remove('show');
  });
  try { window.parent.postMessage({ type: '__edit_mode_available' }, '*'); } catch (e) {}
  $('#open-tweaks-btn')?.addEventListener('click', openPanel);

  /* ============================================================
     STARFIELD (from landing)
     ============================================================ */
  (function starfield() {
    const c = $('#starfield'); if (!c) return;
    const ctx = c.getContext('2d');
    let w, h, dpr, stars = [], shooters = [];
    const accent = () => getComputedStyle(root).getPropertyValue('--a-glow').trim() || '#818cf8';
    function rgb() {
      let hex = accent().replace('#', '');
      if (hex.length === 3) hex = hex.split('').map(x => x + x).join('');
      const n = parseInt(hex, 16);
      return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
    }
    let col = rgb();
    function resize() {
      dpr = Math.min(devicePixelRatio || 1, 2);
      w = c.width = innerWidth * dpr; h = c.height = innerHeight * dpr;
      c.style.width = innerWidth + 'px'; c.style.height = innerHeight + 'px';
      const count = Math.min(720, Math.round(innerWidth * innerHeight / 2800));
      stars = Array.from({ length: count }, () => ({
        x: Math.random() * w, y: Math.random() * h, z: Math.random() * 0.8 + 0.2,
        r: (Math.random() * 1.2 + 0.3) * dpr, tw: Math.random() * Math.PI * 2, ts: Math.random() * 0.04 + 0.01,
      }));
    }
    function spawn() {
      if (reduce) return;
      const fl = Math.random() > 0.5;
      shooters.push({ x: fl ? -50 : w + 50, y: Math.random() * h * 0.5,
        vx: (fl ? 1 : -1) * (5 + Math.random() * 4) * dpr, vy: (1.6 + Math.random() * 1.2) * dpr, life: 1 });
    }
    let last = 0;
    function frame(t) {
      ctx.clearRect(0, 0, w, h);
      const [r, g, b] = col;
      const light = root.getAttribute('data-theme') === 'light';
      for (const s of stars) {
        s.tw += s.ts;
        const a = (light ? 0.55 + Math.sin(s.tw) * 0.25 : 0.35 + Math.sin(s.tw) * 0.3) * s.z;
        ctx.beginPath(); ctx.fillStyle = `rgba(${r},${g},${b},${a})`;
        ctx.arc(s.x, s.y, s.r, 0, 7); ctx.fill();
        s.y += s.z * 0.1 * dpr; if (s.y > h) { s.y = 0; s.x = Math.random() * w; }
      }
      for (let i = shooters.length - 1; i >= 0; i--) {
        const sh = shooters[i]; sh.x += sh.vx; sh.y += sh.vy; sh.life -= 0.012;
        const grad = ctx.createLinearGradient(sh.x, sh.y, sh.x - sh.vx * 6, sh.y - sh.vy * 6);
        grad.addColorStop(0, `rgba(${r},${g},${b},${0.9 * sh.life})`); grad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.strokeStyle = grad; ctx.lineWidth = 2 * dpr; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(sh.x, sh.y); ctx.lineTo(sh.x - sh.vx * 6, sh.y - sh.vy * 6); ctx.stroke();
        if (sh.life <= 0 || sh.x < -80 || sh.x > w + 80) shooters.splice(i, 1);
      }
      if (t - last > 4600 && Math.random() > 0.6) { spawn(); last = t; }
      requestAnimationFrame(frame);
    }
    resize(); addEventListener('resize', resize);
    new MutationObserver(() => { col = rgb(); }).observe(root, { attributes: true, attributeFilter: ['data-accent'] });
    requestAnimationFrame(frame);
  })();

  /* ============================================================
     ROUTER
     ============================================================ */
  function go(page) {
    if (!state.authed) return;
    if (!['library', 'account', 'upgrade'].includes(page)) page = 'library';
    $$('.page').forEach(p => p.classList.toggle('active', p.id === 'page-' + page));
    $$('[data-nav]').forEach(n => {
      const on = n.dataset.nav === page;
      n.classList.toggle('active', on && (n.classList.contains('side-link') || n.classList.contains('tab-item')));
    });
    if (location.hash !== '#' + page) history.replaceState(null, '', '#' + page);
    window.scrollTo(0, 0);
    revealIn(page);
  }
  function revealIn(page) {
    requestAnimationFrame(() => $$('#page-' + page + ' .reveal').forEach((el, i) => {
      setTimeout(() => el.classList.add('in'), i * 60);
    }));
  }
  document.addEventListener('click', e => {
    const nav = e.target.closest('[data-nav]');
    if (nav) { e.preventDefault(); go(nav.dataset.nav); }
  });
  window.addEventListener('hashchange', () => { if (state.authed) go(location.hash.slice(1)); });

  /* ============================================================
     AUTH
     ============================================================ */
  function login() {
    state.authed = true;
    $('#login-stage').style.display = 'none';
    $('#app-shell').classList.remove('hidden');
    hydrateUser();
    renderAll();
    go(location.hash.slice(1) || 'library');
  }
  function logout() {
    state.authed = false;
    $('#app-shell').classList.add('hidden');
    $('#login-stage').style.display = 'grid';
    history.replaceState(null, '', '#');
  }
  $('#google-btn')?.addEventListener('click', () => {
    const b = $('#google-btn'); b.disabled = true; b.style.opacity = '.7';
    b.innerHTML = 'Signing in…';
    setTimeout(login, 650);
  });
  $('#signout-btn')?.addEventListener('click', logout);
  $('#get-ext')?.addEventListener('click', e => { e.preventDefault(); toast('Opens the Chrome Web Store listing'); });
  $('#login-pricing')?.addEventListener('click', e => { e.preventDefault(); login(); setTimeout(() => go('upgrade'), 50); });

  function hydrateUser() {
    const u = D.USER, initial = u.name[0].toUpperCase();
    $('#side-avatar').textContent = initial;
    $('#top-avatar').textContent = initial;
    $('#acc-avatar').textContent = initial;
    $('#side-name').textContent = u.name;
    $('#side-email').textContent = u.email;
    $('#acc-name').textContent = u.name;
    $('#acc-email').textContent = u.email;
    $('#side-saves-count').textContent = state.saves.length;
    const tb = $('#acc-tier'); tb.textContent = cap(u.tier); tb.className = 'tier-badge tier-' + u.tier;
    if (u.tier === 'premium') $('#acc-upgrade-btn').style.display = 'none';
  }

  /* ============================================================
     RENDER — everything
     ============================================================ */
  function renderAll() { renderCollections(); renderSaves(); renderAccount(); renderUpgrade(); }

  // ---- Library ----
  function renderCollections() {
    $('#collections').innerHTML = D.COLLECTIONS.map(c => {
      const n = c.id === 'all' ? state.saves.length
        : c.id === 'fav' ? state.saves.filter(s => s.fav).length
        : state.saves.filter(s => s.collection === c.id).length;
      return `<button class="coll ${c.id === state.collection ? 'active' : ''}" data-coll="${c.id}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9">${ICONS[c.icon]}</svg>
        ${esc(c.name)}<span class="n">${n}</span></button>`;
    }).join('') + `<button class="coll add" id="coll-add"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>New</button>`;
    $$('#collections .coll[data-coll]').forEach(b => b.addEventListener('click', () => {
      state.collection = b.dataset.coll; renderCollections(); renderSaves();
    }));
    $('#coll-add')?.addEventListener('click', () => toast('Collections are created from the extension'));
  }

  function filteredSaves() {
    let list = state.saves.filter(s => {
      const inColl = state.collection === 'all' ? true
        : state.collection === 'fav' ? s.fav : s.collection === state.collection;
      const inMode = state.mode === 'all' || s.mode === state.mode;
      const q = state.search;
      const inSearch = !q || [s.title, s.domain, s.selected, ...(s.tags || [])]
        .join(' ').toLowerCase().includes(q);
      return inColl && inMode && inSearch;
    });
    const by = state.sort;
    list.sort((a, b) => {
      if (by === 'az') return a.title.localeCompare(b.title);
      if (by === 'views') return b.views - a.views;
      const da = +new Date(a.date), db = +new Date(b.date);
      return by === 'oldest' ? da - db : db - da;
    });
    return list;
  }

  function renderSaves() {
    const list = filteredSaves();
    const wrap = $('#saves-list');
    wrap.classList.toggle('grid', state.view === 'grid');
    if (!list.length) {
      wrap.classList.remove('grid');
      wrap.innerHTML = state.saves.length
        ? emptyHTML('search', 'No matches', 'Try a different term, mode, or collection.')
        : emptyHTML('book', 'No saves yet', 'Highlight text in the Explainly extension and tap Save — it shows up here.');
      return;
    }
    wrap.innerHTML = list.map(cardHTML).join('');
    bindCards();
  }

  function cardHTML(s) {
    const fav = state.saves.find(x => x.id === s.id)?.fav;
    return `<article class="card hov save ${state.open[s.id] ? 'open' : ''}" data-id="${s.id}">
      <div class="save-head" data-toggle="${s.id}">
        <div class="save-body-col">
          <div class="save-top">
            <span class="mode-badge mode-${s.mode}">${MODE_LABELS[s.mode]}</span>
            <span class="save-src"><span class="save-fav-dot">${esc((s.domain[0] || 'W').toUpperCase())}</span>${esc(s.domain)} · ${relDate(s.date)}</span>
          </div>
          <h3 class="save-title">${esc(s.title)}</h3>
          <p class="save-snippet">${esc(s.selected)}</p>
          <div class="save-tags">${(s.tags || []).map(t => `<span class="tag">${esc(t)}</span>`).join('')}</div>
        </div>
        <div class="save-actions">
          <button class="icon-btn star ${fav ? 'on' : ''}" data-fav="${s.id}" aria-label="Favorite"><svg viewBox="0 0 24 24" fill="${fav ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><polygon points="12 2 15 9 22 9.3 16.5 14 18.5 21 12 17 5.5 21 7.5 14 2 9.3 9 9 12 2"/></svg></button>
          <button class="icon-btn del" data-del="${s.id}" aria-label="Delete"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg></button>
          <svg class="save-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
        </div>
      </div>
      <div class="save-body">
        <div class="save-selected">${esc(s.selected)}</div>
        ${section('Meaning', s.meaning)}${section('Simpler', s.simpler)}${section('Tone', s.tone)}
        <a class="save-source-link" href="${s.url}" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M7 17 17 7M17 7H9M17 7v8"/></svg>View source</a>
      </div>
    </article>`;
  }
  const section = (l, t) => t ? `<div class="save-section"><span class="lbl">${l}</span><p>${esc(t)}</p></div>` : '';

  function bindCards() {
    $$('[data-toggle]').forEach(h => h.addEventListener('click', e => {
      if (e.target.closest('[data-fav],[data-del]')) return;
      const id = h.dataset.toggle;
      state.open[id] = !state.open[id];
      h.closest('.save').classList.toggle('open', state.open[id]);
    }));
    $$('[data-fav]').forEach(b => b.addEventListener('click', e => {
      e.stopPropagation();
      const s = state.saves.find(x => x.id === b.dataset.fav); if (!s) return;
      s.fav = !s.fav; renderCollections(); renderSaves();
      toast(s.fav ? 'Added to Favorites' : 'Removed from Favorites');
    }));
    $$('[data-del]').forEach(b => b.addEventListener('click', e => {
      e.stopPropagation();
      const card = b.closest('.save'); card.style.opacity = '.35'; card.style.pointerEvents = 'none';
      const id = b.dataset.del;
      setTimeout(() => {
        state.saves = state.saves.filter(x => x.id !== id);
        delete state.open[id];
        $('#side-saves-count').textContent = state.saves.length;
        renderCollections(); renderSaves(); renderAccount();
        toast('Deleted');
      }, 200);
    }));
  }

  // library controls
  let deb;
  $('#search').addEventListener('input', e => {
    clearTimeout(deb); const v = e.target.value.trim().toLowerCase();
    deb = setTimeout(() => { state.search = v; renderSaves(); }, 200);
  });
  $('#sort').addEventListener('change', e => { state.sort = e.target.value; renderSaves(); });
  $('#mode-chips').addEventListener('click', e => {
    const c = e.target.closest('.chip'); if (!c) return;
    $$('#mode-chips .chip').forEach(x => x.classList.remove('active'));
    c.classList.add('active'); state.mode = c.dataset.mode; renderSaves();
  });
  $('#view-toggle').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    $$('#view-toggle button').forEach(x => x.classList.remove('on'));
    b.classList.add('on'); state.view = b.dataset.view; renderSaves();
  });

  // ---- Account ----
  function renderAccount() {
    const u = D.USER;
    // stats
    const stats = [
      { k: 'Explanations', ic: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2Z"/>', v: u.totalExplains.toLocaleString(), d: 'all time' },
      { k: 'Saved', ic: '<path d="M4 5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v16l-8-4-8 4V5Z"/>', v: state.saves.length, d: 'in library' },
      { k: 'Streak', ic: '<path d="M12 2c1 3.5-1.5 5-1.5 7.5 0 1.4 1.1 2.5 2.5 2.5 1.7 0 2.6-1.4 2.4-3 1.6 1.3 2.6 3.3 2.6 5.5a6 6 0 1 1-12 0c0-3.2 2-5.4 3.5-7C9.8 8 9.4 4.6 12 2Z"/>', v: u.streak, d: 'days · best ' + u.streakBest },
      { k: 'Top mode', ic: '<path d="M3 12h4l3 8 4-16 3 8h4"/>', v: u.favMode, d: 'most used' },
    ];
    $('#acc-stats').innerHTML = stats.map(s => `<div class="stat">
      <div class="k"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9">${s.ic}</svg>${s.k}</div>
      <div class="v">${s.v}</div><div class="d">${s.d}</div></div>`).join('');

    // week chart
    const max = Math.max(...D.WEEK.map(d => d.v));
    const total = D.WEEK.reduce((a, b) => a + b.v, 0);
    $('#week-total').textContent = total + ' explains';
    $('#week-chart').innerHTML = D.WEEK.map(d => `<div class="chart-col">
      <span class="cv">${d.v}</span>
      <div class="chart-bar ${d.today ? 'today' : ''}" data-h="${Math.max(6, Math.round(d.v / max * 100))}" style="height:5px"></div>
      <span class="cd">${d.d}</span></div>`).join('');
    requestAnimationFrame(() => $$('#week-chart .chart-bar').forEach(b => { b.style.height = b.dataset.h + '%'; }));

    // streak dots
    $('#streak-num').textContent = u.streak; $('#streak-best').textContent = u.streakBest;
    const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
    $('#streak-dots').innerHTML = days.map((d, i) => `<i class="${i < 6 ? 'on' : ''}">${d}</i>`).join('');

    // usage bars
    const lim = D.TIER_LIMITS[u.tier];
    $('#usage-bars').innerHTML = [
      ['General', D.USAGE.daily, lim.daily], ['Deep', D.USAGE.deep, lim.deep], ['Why?', D.USAGE.why, lim.why],
    ].map(([l, used, limit]) => {
      const pct = limit ? Math.min(100, Math.round(used / limit * 100)) : 0;
      const cls = pct >= 90 ? 'full' : pct >= 70 ? 'warn' : '';
      return `<div class="usage-row"><div class="usage-lbl"><b>${l}</b><span>${used} / ${limit}</span></div>
        <div class="usage-track"><div class="usage-fill ${cls}" data-w="${pct}" style="width:0"></div></div></div>`;
    }).join('');
    requestAnimationFrame(() => $$('#usage-bars .usage-fill').forEach(f => { f.style.width = f.dataset.w + '%'; }));

    // features
    $('#features-list').innerHTML = D.FEATURES.map(f => {
      const ok = D.TIER_ORDER[u.tier] >= D.TIER_ORDER[f.minTier];
      return `<div class="feat-row ${ok ? '' : 'locked'}"><span class="ck">${CHECK}</span><span>${esc(f.label)}</span>
        ${ok ? '' : `<span class="lock-tag">${cap(f.minTier)}+</span>`}</div>`;
    }).join('');
  }

  // settings interactions
  $('#set-default-mode')?.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    $$('#set-default-mode button').forEach(x => x.classList.remove('on')); b.classList.add('on');
    toast('Default depth: ' + b.textContent);
  });
  $$('[data-setting]').forEach(sw => sw.addEventListener('click', () => {
    sw.classList.toggle('on');
    toast(sw.classList.contains('on') ? 'On' : 'Off');
  }));

  // ---- Upgrade ----
  function renderUpgrade() {
    renderPlans();
    // comparison table
    const headPop = 'colpop';
    const cmp = $('#cmp-table');
    cmp.innerHTML = `<thead><tr><th scope="col" style="text-align:left">Feature</th>
      <th scope="col">Free</th><th scope="col" class="${headPop}">Premium</th><th scope="col">Pro</th></tr></thead>
      <tbody>${D.CMP_ROWS.map(r => `<tr>
        <th scope="row">${esc(r.label)}</th>
        <td>${cell(r.free)}</td><td class="${headPop}">${cell(r.premium)}</td><td>${cell(r.pro)}</td></tr>`).join('')}</tbody>`;
  }
  function cell(v) {
    if (v === true)  return '<span class="yes">' + CHECK + '</span>';
    if (v === false) return '<span class="no">—</span>';
    return esc(v);
  }
  function renderPlans() {
    const u = D.USER, p = state.period;
    $('#plans').innerHTML = D.PLANS.map(pl => {
      const pr = pl[p];
      const isCurrent = pl.id === u.tier;
      let badge = '';
      if (isCurrent) badge = '<div class="plan-badge current">Current plan</div>';
      else if (pl.featured) badge = `<div class="plan-badge">${esc(pl.badge)}</div>`;
      else if (p === 'annual' && pr.save) badge = `<div class="plan-badge save">${esc(pr.save)}</div>`;
      const feats = pl.features.map(f => typeof f === 'object'
        ? `<li class="off"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18M6 6l12 12"/></svg>${esc(f.off)}</li>`
        : `<li>${CHECK}${esc(f)}</li>`).join('');
      const cta = isCurrent
        ? `<button class="btn btn-ghost btn-full" disabled>Current plan</button>`
        : `<button class="btn ${pl.featured ? 'btn-primary' : 'btn-ghost'} btn-full" data-buy="${pl.id}">${esc(pl.cta)}</button>`;
      return `<div class="card plan ${pl.featured ? 'featured' : ''} ${isCurrent ? 'current-plan' : ''}">
        ${badge}
        <div class="plan-name">${esc(pl.name)}</div>
        <div class="plan-tag">${esc(pl.tag)}</div>
        <div class="plan-price"><span class="cur">${pr.cur}</span><span class="amt">${pr.amt}</span><span class="per">${pr.per}</span></div>
        <div class="plan-usd">${esc(pr.usd)}</div>
        <ul>${feats}</ul>
        <div class="plan-spacer"></div>
        ${cta}
      </div>`;
    }).join('');
    $$('#plans [data-buy]').forEach(b => b.addEventListener('click', () => buy(b.dataset.buy, b)));
  }

  function buy(id, btn) {
    btn.disabled = true; btn.textContent = 'Opening checkout…';
    setTimeout(() => {
      D.USER.tier = id;
      hydrateUser();
      $('#success-msg').textContent = 'Your account is now ' + cap(id) + '. Enjoy your new features!';
      $('#success-banner').classList.add('show');
      renderPlans(); renderAccount();
      $('#success-banner').scrollIntoView({ behavior: 'smooth', block: 'start' });
      toast('Upgraded to ' + cap(id));
    }, 800);
  }

  // billing toggle
  const bill = $('#bill-toggle'), thumb = $('.thumb', bill);
  function moveThumb(b) { thumb.style.left = b.offsetLeft + 'px'; thumb.style.width = b.offsetWidth + 'px'; }
  bill.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    $$('#bill-toggle button').forEach(x => x.classList.remove('on')); b.classList.add('on');
    state.period = b.dataset.period; moveThumb(b); renderPlans();
  });
  $('#cmp-toggle').addEventListener('click', () => $('#compare').classList.toggle('open'));

  /* ============================================================
     HELPERS
     ============================================================ */
  function emptyHTML(icon, h, p) {
    const svg = icon === 'search'
      ? '<circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>'
      : '<path d="M4 5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v16l-8-4-8 4V5Z"/>';
    return `<div class="empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">${svg}</svg>
      <h3>${h}</h3><p>${p}</p></div>`;
  }
  const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
  function relDate(iso) {
    const diff = Date.now() - new Date(iso).getTime();
    const m = Math.floor(diff / 60000);
    if (m < 1) return 'just now';
    if (m < 60) return m + 'm ago';
    const hrs = Math.floor(m / 60); if (hrs < 24) return hrs + 'h ago';
    const days = Math.floor(hrs / 24); if (days < 30) return days + 'd ago';
    const mo = Math.floor(days / 30); if (mo < 12) return mo + 'mo ago';
    return Math.floor(mo / 12) + 'yr ago';
  }
  let toastT;
  function toast(msg) {
    const el = $('#toast'); el.textContent = msg; el.classList.add('show');
    clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('show'), 2200);
  }

  // boot: thumb position after layout
  requestAnimationFrame(() => { const on = $('#bill-toggle button.on'); if (on) moveThumb(on); });

  // For preview convenience, start signed in. (Reload with #logout to see login.)
  if (location.hash === '#login') { logout(); }
  else { login(); }
})();
