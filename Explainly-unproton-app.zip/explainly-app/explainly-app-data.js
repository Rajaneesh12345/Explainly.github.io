/* ============================================================
   EXPLAINLY APP — mock data
   ============================================================ */
window.EX = (function () {
  'use strict';

  const USER = {
    name: 'Alex Rivera',
    email: 'alex@gmail.com',
    tier: 'free',          // free | pro | premium
    memberSince: 'Mar 2025',
    streak: 12,
    streakBest: 21,
    totalExplains: 1284,
    favMode: 'Normal',
  };

  // tier limits (today's usage)
  const TIER_LIMITS = {
    free:    { daily: 20,  deep: 3,  why: 3  },
    pro:     { daily: 100, deep: 10, why: 10 },
    premium: { daily: 500, deep: 75, why: 75 },
  };
  const TIER_ORDER = { free: 0, pro: 1, premium: 2 };

  // today's usage (used counts)
  const USAGE = { daily: 14, deep: 2, why: 1 };

  // 7-day activity (Mon..Sun-ish, last is "today")
  const WEEK = [
    { d: 'Mon', v: 18 }, { d: 'Tue', v: 31 }, { d: 'Wed', v: 12 },
    { d: 'Thu', v: 44 }, { d: 'Fri', v: 27 }, { d: 'Sat', v: 9 },
    { d: 'Sun', v: 14, today: true },
  ];

  const COLLECTIONS = [
    { id: 'all',     name: 'All',          icon: 'grid' },
    { id: 'fav',     name: 'Favorites',    icon: 'star' },
    { id: 'reading', name: 'Reading list', icon: 'book' },
    { id: 'work',    name: 'Work',         icon: 'brief' },
    { id: 'science', name: 'Science',      icon: 'atom' },
  ];

  // saved explanations
  const SAVES = [
    {
      id: 's1', mode: 'deep', fav: true, collection: 'science', views: 23,
      title: 'Quantum entanglement', domain: 'en.wikipedia.org', date: '2025-06-03T09:12:00',
      tags: ['physics', 'quantum'],
      selected: 'When two particles interact in certain ways, the quantum state of each particle cannot be described independently of the state of the others.',
      meaning: 'Two particles share a single, non-separable quantum state. Measuring one instantly fixes the correlated outcome of the other — even across vast distances.',
      simpler: 'Think of two coins that are magically linked: flip one and the other always lands the opposite way, no matter how far apart they are.',
      tone: 'Neutral and technical — drawn from an encyclopedic source.',
      url: '#',
    },
    {
      id: 's2', mode: 'eli5', fav: false, collection: 'science', views: 8,
      title: 'What is a black hole?', domain: 'nasa.gov', date: '2025-06-02T18:40:00',
      tags: ['space', 'gravity'],
      selected: 'A black hole is a region of spacetime where gravity is so strong that nothing can escape from it.',
      meaning: 'A place in space where gravity is so strong that not even light can get out once it crosses the edge.',
      simpler: 'Imagine a drain so powerful that anything nearby — even a beam of light — gets pulled in and can never climb back out.',
      tone: 'Friendly and simple, aimed at a curious beginner.',
      url: '#',
    },
    {
      id: 's3', mode: 'normal', fav: true, collection: 'work', views: 41,
      title: 'Amortization schedule', domain: 'investopedia.com', date: '2025-06-02T11:05:00',
      tags: ['finance', 'loans'],
      selected: 'An amortization schedule is a table detailing each periodic payment on a loan over time.',
      meaning: 'A breakdown of every loan payment, showing how much goes to interest versus the principal each month until the balance reaches zero.',
      simpler: 'A month-by-month plan that shows how a loan gets paid off, splitting each payment between fees and what you actually borrowed.',
      tone: 'Plain financial explainer.',
      url: '#',
    },
    {
      id: 's4', mode: 'why', fav: false, collection: 'reading', views: 5,
      title: 'The hard problem of consciousness', domain: 'plato.stanford.edu', date: '2025-06-01T20:22:00',
      tags: ['philosophy', 'mind'],
      selected: 'The hard problem of consciousness is the problem of explaining why and how we have qualia or phenomenal experiences.',
      meaning: 'It asks why physical brain activity is accompanied by subjective experience at all — why there is "something it is like" to see red.',
      simpler: 'Why does a lump of grey matter feel anything? We can map the wiring, but not why it produces an inner movie.',
      tone: 'This line is dense because it leans on the unexplained jargon "qualia" and compresses a famously contested debate into a single sentence.',
      url: '#',
    },
    {
      id: 's5', mode: 'normal', fav: false, collection: 'work', views: 17,
      title: 'Idempotency in APIs', domain: 'stripe.com', date: '2025-05-31T14:48:00',
      tags: ['api', 'engineering'],
      selected: 'An idempotent operation can be applied multiple times without changing the result beyond the initial application.',
      meaning: 'Calling the same request twice has the same effect as calling it once — handy for safely retrying payments after a network blip.',
      simpler: 'Pressing the button again does nothing extra. One charge, no matter how many times the request is sent.',
      tone: 'Developer-docs tone, precise and practical.',
      url: '#',
    },
    {
      id: 's6', mode: 'deep', fav: true, collection: 'reading', views: 12,
      title: 'Bayesian inference', domain: 'towardsdatascience.com', date: '2025-05-30T08:15:00',
      tags: ['stats', 'ml'],
      selected: 'Bayesian inference updates the probability for a hypothesis as more evidence becomes available.',
      meaning: 'A method that revises beliefs in light of new data: you start with a prior, observe evidence, and compute a posterior via Bayes\u2019 theorem.',
      simpler: 'Start with a guess, then nudge it every time new evidence comes in until your guess matches reality.',
      tone: 'Tutorial tone with mild mathematical rigor.',
      url: '#',
    },
    {
      id: 's7', mode: 'eli5', fav: false, collection: 'science', views: 3,
      title: 'Why is the sky blue?', domain: 'scied.ucar.edu', date: '2025-05-29T16:30:00',
      tags: ['light', 'physics'],
      selected: 'Rayleigh scattering causes shorter wavelengths of light to scatter more than longer wavelengths.',
      meaning: 'Sunlight hits air molecules and the blue part bounces around the sky far more than the red part, so the whole sky looks blue.',
      simpler: 'Sunlight is secretly all colours. Tiny bits of air bounce the blue around everywhere, so up looks blue.',
      tone: 'Cheerful classroom explanation.',
      url: '#',
    },
    {
      id: 's8', mode: 'normal', fav: false, collection: 'reading', views: 9,
      title: 'Compound interest', domain: 'khanacademy.org', date: '2025-05-28T10:00:00',
      tags: ['finance', 'money'],
      selected: 'Compound interest is interest calculated on the initial principal and also on the accumulated interest.',
      meaning: 'Your money earns interest, then that interest earns its own interest — growth speeds up the longer you leave it.',
      simpler: 'A snowball rolling downhill: it grows, and the bigger it gets the faster it grows.',
      tone: 'Educational, beginner-friendly.',
      url: '#',
    },
  ];

  // account feature list (with min tier)
  const FEATURES = [
    { label: 'AI explanations — ELI5, Normal, Deep, Why?', minTier: 'free' },
    { label: 'Local saves (up to 50)',                     minTier: 'free' },
    { label: 'PDF viewer support',                          minTier: 'pro' },
    { label: 'Cloud sync (unlimited saves)',                minTier: 'pro' },
    { label: 'Collections, tags & smart search',            minTier: 'pro' },
    { label: 'Priority processing queue',                   minTier: 'premium' },
    { label: 'Premium AI models',                           minTier: 'premium' },
  ];

  // plans (monthly + annual)
  const PLANS = [
    {
      id: 'free', name: 'Free', tag: 'For the occasional reader', featured: false,
      monthly: { cur: '$', amt: '0',  per: '/mo', usd: 'Free forever' },
      annual:  { cur: '$', amt: '0',  per: '/yr', usd: 'Free forever' },
      cta: 'Current plan',
      features: ['20 explains / day', '3 Deep · 3 Why? / day', 'Local saves (50)', { off: 'PDF viewer' }, { off: 'Cloud sync' }],
    },
    {
      id: 'pro', name: 'Pro', tag: 'For regular readers', featured: false,
      monthly: { cur: '$', amt: '4.99', per: '/mo', usd: '₹149 / month' },
      annual:  { cur: '$', amt: '3.33', per: '/mo', usd: '$39.99 / year' },
      cta: 'Get Pro',
      features: ['100 explains / day', '10 Deep · 10 Why? / day', 'PDF viewer', 'Cloud sync (unlimited)', 'Collections & tags'],
    },
    {
      id: 'premium', name: 'Premium', tag: 'For power users', featured: true, badge: 'Most popular',
      monthly: { cur: '$', amt: '11.99', per: '/mo', usd: '₹399 / month' },
      annual:  { cur: '$', amt: '8.25',  per: '/mo', usd: '$99 / year', save: 'Save ~37%' },
      cta: 'Get Premium',
      features: ['500 explains / day', '75 Deep · 75 Why? / day', 'Everything in Pro', 'Priority queue', 'Premium AI models'],
    },
  ];

  // comparison table
  const CMP_ROWS = [
    { label: 'Explains / day',        free: '20',  pro: '100', premium: '500' },
    { label: 'Deep mode / day',       free: '3',   pro: '10',  premium: '75' },
    { label: 'Why? mode / day',       free: '3',   pro: '10',  premium: '75' },
    { label: 'Saved explanations',    free: '50',  pro: '∞',   premium: '∞' },
    { label: 'Collections & tags',    free: false, pro: true,  premium: true },
    { label: 'Cloud sync',            free: false, pro: true,  premium: true },
    { label: 'PDF viewer',            free: false, pro: true,  premium: true },
    { label: 'Priority queue',        free: false, pro: false, premium: true },
    { label: 'Premium AI models',     free: false, pro: false, premium: true },
  ];

  return { USER, TIER_LIMITS, TIER_ORDER, USAGE, WEEK, COLLECTIONS, SAVES, FEATURES, PLANS, CMP_ROWS };
})();
